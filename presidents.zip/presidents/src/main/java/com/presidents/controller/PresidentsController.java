package com.presidents.controller;

import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("presidents")
public class PresidentsController {
}

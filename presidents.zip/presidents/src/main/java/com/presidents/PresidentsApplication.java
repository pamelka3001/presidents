package com.presidents;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PresidentsApplication {

    public static void main(String[] args) {
        SpringApplication.run(PresidentsApplication.class, args);
    }

}

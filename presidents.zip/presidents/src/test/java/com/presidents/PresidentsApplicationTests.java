package com.presidents;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PresidentsApplicationTests {

    @Test
    void contextLoads() {
    }

}
